package com.example.myapplication;

public abstract class Entry {
    private String foodName;
    private double calories;

    private Integer total;

    public Entry(String foodName, double calories, Integer total) {
        this.foodName = foodName;
        this.calories = calories;
        this.total = total;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public double getCalories() {
        return calories * total;
    }

    public void setCalories(double calories) {
        this.calories = calories;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }
    public abstract String getDetails();
}