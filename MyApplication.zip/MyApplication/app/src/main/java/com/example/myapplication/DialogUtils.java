package com.example.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class DialogUtils {
    public interface AddEntryListener {
        void onAddEntry(String foodName, double calories, Integer total);
    }

    public static void openAddEntryDialog(Context context, final AddEntryListener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.activity_add_entry, null);

        final EditText editTextFoodName = dialogView.findViewById(R.id.editTextFoodName);
        final EditText editTextCalories = dialogView.findViewById(R.id.editTextCalories);
        final EditText editTextTotal = dialogView.findViewById(R.id.editTextTotal);

        builder.setView(dialogView)
                .setTitle("Add Food")
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    // untuk Validasi
                    String foodName = editTextFoodName.getText().toString().trim();
                    String caloriesText = editTextCalories.getText().toString().trim();

                    String totalText = editTextTotal.getText().toString().trim();




                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String foodName = editTextFoodName.getText().toString().trim();
                        String caloriesText = editTextCalories.getText().toString().trim();
                        String totalText = editTextTotal.getText().toString().trim();

                        if (TextUtils.isEmpty(foodName) || TextUtils.isEmpty(caloriesText) || TextUtils.isEmpty(totalText)) {
                            // Show an error if either field is empty
                            Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                        } else {
                            double calories = Double.parseDouble(caloriesText);
                            Integer total = Integer.parseInt(totalText);

                            if (listener != null) {
                                listener.onAddEntry(foodName, calories, total);
                            }
                        }
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });

        builder.create().show();
    }
}